"use strict";
// Export the cspell settings to the client.
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultDictionaryType = void 0;
exports.defaultDictionaryType = 'S';
//# sourceMappingURL=cspellConfig.js.map