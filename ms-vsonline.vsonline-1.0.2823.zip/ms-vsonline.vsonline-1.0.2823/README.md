# Microsoft Visual Studio Codespaces

Visual Studio Codespaces (formerly Visual Studio Online) provides cloud-hosted development environments for any activity - whether it's a long-term project, or a short-term task like reviewing a pull request. You can create a new Codespace through [Visual Studio Codespaces](https://online.visualstudio.com/) or by [signing up for the GitHub beta](https://github.com/features/codespaces). You can connect to Codespaces from Visual Studio Code, Visual Studio ([sign up for the Private Preview](https://aka.ms/vsfutures-signup)), or a browser-based editor that's accessible anywhere! You can even connect your own self-hosted environments to Visual Studio Codespaces at no cost.

Additionally, Visual Studio Codespaces brings many of the benefits of DevOps, like repeatability and reliability, which have typically been reserved for production workloads, to development environments. However, Visual Studio Codespaces is also personaliazable to allow developers to leverage the tools, processes and configurations that they have come to love and rely on - truly the best of both worlds!

## Getting Started
- Visual Studio Codespaces: [Instructions for getting started](https://aka.ms/vso-docs/quickstart/vscode) with this Visual Studio Code extension are available in our [documentation](https://aka.ms/vso-docs).

- Codespaces in GitHub: First [sign up for the beta](https://github.com/features/codespaces) and then [follow the instructions for getting started](https://help.github.com/github/developing-online-with-codespaces).

## More Information
- [Announcing Visual Studio Codespaces Public Preview](https://aka.ms/vsoblog) (Blog Post)
- [Visual Studio Codespaces Documentation](https://aka.ms/vso-docs)
- [Report a Problem](https://github.com/MicrosoftDocs/vscodespaces/issues/new) (Issue Tracker)