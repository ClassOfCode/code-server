const {exec} = require("child_process");
const {promisify} = require("util");

const glob = require("glob");

const pGlob = promisify(glob);
const pExec = promisify(exec);

module.exports = class SentryUploadSourcesPlugin {
  constructor(env) {
    this.env = env;

  }
  apply(compiler) {
    compiler.hooks.afterEmit.tapAsync("sentry-upload-sources-plugin", async (compilation, callback) => {
      const files = await pGlob("{src,lib}/**/*.{ts,js}");

      try {
        await pExec(`node_modules/.bin/sentry-cli releases info ${this.env.sentryRelease}`);
      } catch (err) {
        if (!/no such release/i.test(err.stdout)) { throw err; }
        await pExec(`node_modules/.bin/sentry-cli releases new ${this.env.sentryRelease}`);
      }

      await pExec(`node_modules/.bin/sentry-cli releases files ${this.env.sentryRelease} delete --all`);
      await Promise.all((files.map(async (file) => {
        await pExec(`node_modules/.bin/sentry-cli releases files ${this.env.sentryRelease} upload ${file} -- webpack:/glitch.glitch/${file}`);
      })));

      callback();
    });
  }
};
